import java.util.*;

public class AddStrings {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String a = sc.next();
        String b = sc.next();

        int num1 = Integer.parseInt(a);
        int num2 = Integer.parseInt(b);

        System.out.println(num1 + num2);
    }
}
